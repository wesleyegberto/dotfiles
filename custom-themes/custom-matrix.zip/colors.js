// This file can be used with the themer CLI, see https://github.com/mjswensen/themer

module.exports.colors = {
  "dark": {
    "shade0": "#0F0F0D",
    "shade7": "#23FF00",
    "accent0": "#FF0018",
    "accent1": "#3C48FF",
    "accent2": "#FFE500",
    "accent3": "#139E00",
    "accent4": "#2900FF",
    "accent5": "#9E65FF",
    "accent6": "#AB00FF",
    "accent7": "#F200FF"
  }
};

// Your theme's URL: https://themer.dev/?colors.dark.shade0=%230f0f0d&colors.dark.shade7=%2323ff00&colors.dark.accent0=%23ff0018&colors.dark.accent1=%233c48ff&colors.dark.accent2=%23ffe500&colors.dark.accent3=%23139e00&colors.dark.accent4=%232900ff&colors.dark.accent5=%236d0fff&colors.dark.accent6=%23ab00ff&colors.dark.accent7=%23f200ff&activeColorSet=dark
